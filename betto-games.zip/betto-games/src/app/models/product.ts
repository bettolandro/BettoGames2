export interface Product {
  id: string;
  title: string;
  price: number;
  stock: number;
  category: string;
  cover: string;
  desc: string;
}